#include "triangulo.h"
#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
    Triangulo tri(5,5,11);

    tri.todos100();

    return 0;
}
